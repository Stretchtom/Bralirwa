package com.example.wendy_guo.j4sp.pojo;

/**
 * Created by Wendy_Guo on 4/2/15.
 */
public interface ActivityCallBack {
    void callBack();

}
