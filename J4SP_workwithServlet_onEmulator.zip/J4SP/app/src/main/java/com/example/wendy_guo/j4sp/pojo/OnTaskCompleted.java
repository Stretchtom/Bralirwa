package com.example.wendy_guo.j4sp.pojo;

/**
 * Created by Wendy_Guo on 3/24/15.
 */
public interface OnTaskCompleted {
    void onTaskCompleted(String feedback);
}
